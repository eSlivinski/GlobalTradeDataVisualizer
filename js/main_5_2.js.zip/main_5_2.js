

$(document).ready(function($) {
  initMap();
  initSelectorMap();
  $('#stateChooser').modal();

  // GeoJSON layer to hold the circles
  centroidLayer = L.geoJson(null, {
    pointToLayer: function (feature, latlng) {
      var coords = new L.LatLng(latlng.lat, latlng.lng);
      return L.circleMarker(coords, {
        radius: 0,
        fillColor: "#E08214",
        color: "#000000",
        weight: 0.2,
        opacity: 1,
        fillOpacity: 0.8      
      });
    },
    onEachFeature: function(feature, layer) {
      layer.on("mouseover", function() {
        layer.setStyle({weight:1.2});
      });
      layer.on("mouseout", function() {
        layer.setStyle({weight:0.2});
      });
    }
  }).addTo(map);

  var superbutton= L.control({position: 'topleft'});

  superbutton.onAdd = function(){
    var div = L.DomUtil.create('div', 'chooser');

    div.innerHTML += '<button id = "superbutton" class="btn-info" type="button">superbutton</button>'

    return div;

  };
  superbutton.addTo(map);

  var wonderbutton= L.control({position: 'topleft'});

  wonderbutton.onAdd = function(){
    var div = L.DomUtil.create('div', 'chooser');

    div.innerHTML += '<button id = "wonderbutton" class="btn-success" type="button">wonderbutton</button>'

    return div;

  };
  wonderbutton.addTo(map);

  // Add the slider to the map frame
  var controls = L.control({position: 'bottomright'});

  controls.onAdd = function (map) {
      var slider = L.DomUtil.create('div', 'info legend jui-slider');
      slider.innerHTML += '<p id="year"></p>';

      var sliderControl = L.DomUtil.create('div', 'holder', slider);
      sliderControl.id = 'slider';

      L.DomEvent.addListener(sliderControl, 'mousedown', function(e) {
          L.DomEvent.stopPropagation(e);
      });

      return slider;
  };

  controls.addTo(map);


  legend = L.control({position: 'bottomleft'});

    legend.onAdd = function (map) {

        var div = L.DomUtil.create('div', 'info legend'),

            types = ['Increase', 'Decrease'],
            colors = ['#B2182B', '#2166AC'];

            for (i=0; i<2; i++){
              div.innerHTML += 
              '<i style="background:' + colors[i] + '""></i> ' + types[i] + '<br></div>';
                    
            }

            div.innerHTML += "<br><img src='css/img/MAFC_logo_Small.png' alt='logo' height='52.5 px' width = '113px'</>";

        return div;
    };

    legend.addTo(map);


      

  // Load the centroid geometry via TopoJSON
  $.getJSON('js/centroids.json', function (data) {
    var input_geojson = topojson.object(data, data.objects.country_centroids);

    input_geojson.geometries.forEach(function(d){
      d.LatLng = new L.LatLng(d.coordinates[0], d.coordinates[1]);
      centroidLayer.addData(d);
    });

  });

  $('#superbutton').click(function rawData(e) {
    console.log('superbutton');

  });

  $('#wonderbutton').click(function changeData(e) {
    console.log('wonder');
  });

  // Pick a state, load its data
  function loadData(state) {  
    d3.csv("data/" + state + "_change2.csv", function(data) {
      dataset = data;
      var availableYears = [];
      for (each in dataset[0]) {

        availableYears.push(each);
      }
      availableYears.splice( availableYears.indexOf("name"), 1);
      availableYears.splice( availableYears.indexOf("id"), 1);

      var min = d3.min(availableYears);
      var max = d3.max(availableYears);

      $('#slider').slider({
        value:parseInt(min),
        min: parseInt(min),
        max: parseInt(max),
        step: 1,
        slide: function(event, ui) {
          $("#year").html(ui.value);
          current = ui.value;
          changeYear(current);
        }
      });

      d3.select("#year").html(min);
      setupMap(dataset, min);
    });
  }



  // Now style the map using the first year of data available
  function setupMap(data, year) {
    //In order to properly build a scale, we need to create a sorted array of possible value

    var toMap = []
    for (i=0;i<data.length;i++) {
      if (parseInt(100*(Math.abs(dataset[i][year])))>0){
        toMap.push(parseInt(Math.abs(dataset[i][year])*100))
      } 
    }

    toMap = toMap.sort(d3.ascending);

    jenks = d3.scale.threshold()
      .domain(ss.jenks(toMap.map(function(d) { return + d ; }), 10))
      .range(['4', '5', '9', '12', '15','20', '25','30', '35','40','45', '50']);//These numbers are the radius sizes

    changeYear(year);
  };
  // End setupMap

  

  // Called when the slider changes and when the map is loaded; changes the map symbology
  function changeYear(year) {
    d3.select("#year").html(year);
    //console.log(year)

    for(j=0;j<dataset.length;j++) {
      //console.log((parseInt((Math.abs(dataset[j][year])*100))))
      for (i in centroidLayer._layers) {
        //console.log(centroidLayer._layers[i].feature.id)
        if (centroidLayer._layers[i].feature.id == dataset[j].number) {

          if (dataset[j][year] == '0') {
            centroidLayer._layers[i].setStyle({ radius: 0 });
          } else {
            centroidLayer._layers[i].unbindPopup()
              .bindPopup("<strong>" + dataset[j].Partner + "</strong><br>Change from " + (year-1) + ": " + dataset[j][year]+ ": ")
              .setStyle({radius: jenks(parseInt((Math.abs(dataset[j][year])*100)))})
              .setStyle({fillColor: colorRamp(parseInt(100*(dataset[j][year])))});
          }
        }
      }
    }
    function colorRamp(d) {
      return d < 0 ? '#B2182B' :
          '#2166AC';
    };
  };

 
  // Builds the SVG map used to select a state
  function initSelectorMap() {
    var projection = d3.geo.albersUsa()
      .scale(1100);

    var path = d3.geo.path()
      .projection(projection);

    var svg = d3.select("#stateChooserMap")
      .append("svg")
        .attr("id", "svgMap")
      .append("g")
        .attr("id", "gMap");


    d3.json("js/us-states.json", function(error, us) {
      svg.selectAll(".states")
      .data(topojson.object(us, us.objects.states).geometries)
      .enter().append("path")
      .attr("class", "states")
      .attr("d", path)
      .attr("id", function(d) {return d.properties.postal;})
      .on("click", function(d) {
        loadData(d3.select(this).attr("id").toLowerCase())
        $('#stateChooser').modal('hide');
      });
    });
    scaleMap();
  }

  function scaleMap() {
    $('#gMap').attr('transform', 'scale(' + 570/900 +')');
    $('#svgMap').height(570*0.618);
    $('#svgMap').css('height', $('#svgMap').height()*0.92);
    $('#svgMap').css('width', 570);
  }

  resize();

});
//End document.ready callback