$(document).ready(function($) {
  initMap();

  var currentYear = 2003,

  colorRamp = d3.scale.linear()
    .domain([0, 0.5, 1])
    .range(["#31A354", "#F4F4F4", "#000"]),

  legend = L.control({position: 'bottomleft'});

  legend.onAdd = function (map) {

      var div = L.DomUtil.create('div', 'info legend'),
          types = ['Coal', 'Natural Gas'],
          colors = ['#333', '#31A354'];

      var j = 0;
      for(i=0;i<11;i++) {
        if (j == 0) {
          div.innerHTML += '<div class="legendRamp" style="background-color: ' + colorRamp(j) + '"></div><p class="lLabel">All Natural Gas</p>';
        } else if (j == 0.5) {
          div.innerHTML += '<div class="legendRamp" style="background-color: ' + colorRamp(j) + '"></div><p class="lLabel">Half & Half</p>';
        } else if (j > 0.9) {
          div.innerHTML += '<div class="legendRamp" style="background-color: ' + colorRamp(j) + '"></div><p class="lLabel">All Coal</p>';
        } else {
          div.innerHTML += '<div class="legendRamp" style="background-color: ' + colorRamp(j) + '"></div>';
        }
        j += 0.1;
      }

      div.innerHTML += "<br><img src='css/img/MAFC_logo_Small.png' alt='logo' height='52.5 px' width = '113px'</>";

      return div;
  };

  legend.addTo(map);

  var controls = L.control({position: 'bottomright'});

  controls.onAdd = function (map) {
      var slider = L.DomUtil.create('div', 'info legend jui-slider');
      slider.innerHTML += '<p id="year">2003</p>';

      var sliderControl = L.DomUtil.create('div', 'holder', slider);
      sliderControl.id = 'slider';

      L.DomEvent.addListener(sliderControl, 'mousedown', function(e) {
          L.DomEvent.stopPropagation(e);
      });

      return slider;
  };

  controls.addTo(map);

  /* Initialize the SVG layer */
  map._initPathRoot();

  var svg = d3.select("#map").select("svg"),
      g = svg.append("g");

  function createRamp(year) {
    points.attr("fill", function(d) {
      return colorRamp(Math.abs(parseFloat(d['sum_' + year + '_coal'] / d['sum_' + year])));
    });
  }

  d3.csv("coal_ng.csv", function(data) {
    var dataset = data;
    dataset.forEach(function(d) {
      d.LatLng = new L.LatLng(d.lat, d.lon)
    });

    jenks = d3.scale.threshold()
      .domain(ss.jenks(dataset.map(function(d) { return + d.sum_2003; }), 6))
      .range(['2', '3', '7', '10', '20', '30', '40']);

    points = g.selectAll(".circle")
      .data(dataset)
      .enter().append("circle")
      .attr("class", "ppStyle")
      .attr("r", function(d) {
        return jenks(Math.abs(d['sum_' + currentYear]))
      })
      .on("mouseover", function(d) {
        //console.log(d['sum_' + currentYear]);
      });

    for (each in points[0]) { 
      var radius = d3.select(points[0][each]).attr("r");
      d3.select(points[0][each]).attr("r", radius/1.5);
    }
    map.on("viewreset", function() {
      update();
    });

    update();
  });


  function update() {
    points.attr("cx",function(d) { return map.latLngToLayerPoint(d.LatLng).x});
    points.attr("cy",function(d) { return map.latLngToLayerPoint(d.LatLng).y});
    if (map.getZoom() <= 5 && d3.select(points[0][0]).attr("r") === "3") {
        for (each in points[0]) { 
          var radius = d3.select(points[0][each]).attr("r");
          d3.select(points[0][each]).attr("r", radius/1.5);
        }
      } else if (map.getZoom() > 5 && d3.select(points[0][0]).attr("r") === "2"){
        for (each in points[0]) { 
          var radius = d3.select(points[0][each]).attr("r");
          d3.select(points[0][each]).attr("r", radius*1.5);
        }
      }
    createRamp(currentYear);
  }

  function changeYear() {
    createRamp(currentYear);
    points.attr("cx",function(d) { return map.latLngToLayerPoint(d.LatLng).x})
    points.attr("cy",function(d) { return map.latLngToLayerPoint(d.LatLng).y})
    points.transition()
      .duration(1000)
      .attr("r",function(d) { return jenks(Math.abs(d['sum_' + currentYear])) });
  }

  $(function() {  
    $('#slider').slider({
    value:2003,
    min: 2003,
    max: 2011,
    step: 1,
    slide: function(event, ui) {
      $("#year").html(ui.value);
      currentYear = ui.value;
      $("[id=infoyear]").html(ui.value);
      changeYear();
    }
    });
  });

  resize();

});
//End document.ready callback