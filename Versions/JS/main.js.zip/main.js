

$(document).ready(function($) {
  initMap();
  initSelectorMap();
  $('#stateChooser').modal();

  // GeoJSON layer to hold the circles
  centroidLayer = L.geoJson(null, {
    pointToLayer: function (feature, latlng) {
      var coords = new L.LatLng(latlng.lat, latlng.lng);
      return L.circleMarker(coords, {
        radius: 0,
        fillColor: "#E08214",
        color: "#000000",
        weight: 0.2,
        opacity: 1,
        fillOpacity: 0.8      
      });
    },
    onEachFeature: function(feature, layer) {
      layer.on("mouseover", function() {
        layer.setStyle({weight:1.2});
      });
      layer.on("mouseout", function() {
        layer.setStyle({weight:0.2});
      });
    }
  }).addTo(map);

  // Add the slider to the map frame
  var controls = L.control({position: 'bottomright'});

  controls.onAdd = function (map) {
      var slider = L.DomUtil.create('div', 'info legend jui-slider');
      slider.innerHTML += '<p id="year"></p>';

      var sliderControl = L.DomUtil.create('div', 'holder', slider);
      sliderControl.id = 'slider';

      L.DomEvent.addListener(sliderControl, 'mousedown', function(e) {
          L.DomEvent.stopPropagation(e);
      });

      return slider;
  };

  controls.addTo(map);

  // Load the centroid geometry via TopoJSON
  $.getJSON('js/centroids.json', function (data) {
    var input_geojson = topojson.object(data, data.objects.country_centroids);

    input_geojson.geometries.forEach(function(d){
      d.LatLng = new L.LatLng(d.coordinates[0], d.coordinates[1]);
      centroidLayer.addData(d);
    });

  });

  // Pick a state, load its data
  function loadData(state) {    
    d3.csv("data/" + state + "_change.csv", function(changeData){
      changeset = changeData;//Defining the dataset as changeset--changeData is really just an alias given by the function deffincition
     }),

    d3.csv("data/" + state + "_data.csv", function(data) {
      dataset = data;
      var availableYears = [];
      for (each in dataset[0]) {
        availableYears.push(each);
      }
      availableYears.splice( availableYears.indexOf("name"), 1);
      availableYears.splice( availableYears.indexOf("id"), 1);

      var min = d3.min(availableYears);
      var max = d3.max(availableYears);

      $('#slider').slider({
        value:parseInt(min),
        min: parseInt(min),
        max: parseInt(max),
        step: 1,
        slide: function(event, ui) {
          $("#year").html(ui.value);
          current = ui.value;
          changeYear(current);
        }
      });

      d3.select("#year").html(min);
      setupMap(dataset, min, changeset);
    });
  }



  // Now style the map using the first year of data available
  function setupMap(data, year, changeData) {
    //In order to properly build a scale, we need to create a sorted array of possible values
    var changetoMap = [];
    for (i=0; i<changeset.length; i++){
      changetoMap.push((parseFloat(changeset[i][year])*100).toFixed(2))
      ;
    }

    changetoMap = changetoMap.sort(d3.ascending);
    console.log(changetoMap)




    var toMap = [];
    for (i=0;i<data.length;i++) {
        toMap.push(parseInt(data[i][year]));
    }

    toMap = toMap.sort(d3.ascending);

    jenks = d3.scale.threshold()
      .domain(ss.jenks(toMap.map(function(d) { return + d; }), 6))
      .range(['2', '3', '7', '10', '20', '30', '40', '50']);

    changeYear(year,changetoMap);
  }
  // End setupMap

  // Called when the slider changes and when the map is loaded; changes the map symbology
  function changeYear(year, changetoMap) {
    d3.select("#year").html(year);

    for(j=0;j<dataset.length;j++) {
      for (i in centroidLayer._layers) {
        if (centroidLayer._layers[i].feature.id == dataset[j].id) {
          if (dataset[j][year] == '0') {
            centroidLayer._layers[i].setStyle({ radius: 0 });
          } else {
            centroidLayer._layers[i].unbindPopup()
              .bindPopup("<strong>" + dataset[j].name + "</strong><br>Exports " + year + ": " + dataset[j][year]+ "<br>Change from " +(year-1)+ ": " + ((parseFloat(changeset[j][year])*100).toFixed(2))+"%")
              .setStyle({fillColor: colorRamp(parseInt((changeset[j][year])*100).toFixed(2))})
              .setStyle({radius: parseInt(jenks(Math.abs(dataset[j][year]))) });
          }
        }
      }
    }
    function colorRamp(d) {
      return (10+d) < 0 ? '#CA0020' :
        d < 0 ? '#F4A582':
        d == 0 ? '#fff':
        d < 25 ?'#92C5DE':
          '#0571B0';

    };
  };

 
  // Builds the SVG map used to select a state
  function initSelectorMap() {
    var projection = d3.geo.albersUsa()
      .scale(1100);

    var path = d3.geo.path()
      .projection(projection);

    var svg = d3.select("#stateChooserMap")
      .append("svg")
        .attr("id", "svgMap")
      .append("g")
        .attr("id", "gMap");

    //Load the topojson
    d3.json("js/us-states.json", function(error, us) {
      svg.selectAll(".states")
      .data(topojson.object(us, us.objects.states).geometries)
      .enter().append("path")
      .attr("class", "states")
      .attr("d", path)
      .attr("id", function(d) {return d.properties.postal;})
      .on("click", function(d) {
        loadData(d3.select(this).attr("id").toLowerCase())
        $('#stateChooser').modal('hide');
      });
    });
    scaleMap();
  }

  function scaleMap() {
    $('#gMap').attr('transform', 'scale(' + 570/900 +')');
    $('#svgMap').height(570*0.618);
    $('#svgMap').css('height', $('#svgMap').height()*0.92);
    $('#svgMap').css('width', 570);
  }

  resize();

});
//End document.ready callback